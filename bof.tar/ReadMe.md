**Author:** ypp
**Difficulty:** Baby
**Category:** Pwn
 
---

Easy Buffer Overflow!!

---

flag：is1abCTF{PwN_!s_iN7ERE5T1n6_RIght?}
原始碼：是
題目檔案：除了 flag 整包都給
題目名稱：bof
題目類型：靜態容器

---

## build env 
- `docker compose up --build -d`
- port `40001`
